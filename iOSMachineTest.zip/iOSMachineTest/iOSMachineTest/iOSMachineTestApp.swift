//
//  iOSMachineTestApp.swift
//  iOSMachineTest
//
//  Created by Mc on 20/03/24.
//

import SwiftUI

@main
struct iOSMachineTestApp: App {
    var body: some Scene {
        WindowGroup {
            GroupListView()
        }
    }
}
